package com.example.markscal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity { //implements View.OnClickListener {
    public static int SPLASH_TIME_OUT =3000;
    EditText input1, input2, input3, input4, input5, input6;
    TextView total, percent;
    Button btntotal, btnpercent;

    int sum, i1, i2, i3, i4, i5, i6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input1 = (EditText) findViewById(R.id.input1);
        input2 = (EditText) findViewById(R.id.input2);
        input3 = (EditText) findViewById(R.id.input3);
        input4 = (EditText) findViewById(R.id.input4);
        input5 = (EditText) findViewById(R.id.input5);
        input6 = (EditText) findViewById(R.id.input6);
        btntotal = (Button) findViewById(R.id.btntotal);
        btnpercent = (Button) findViewById(R.id.btnpercent);
        total = (TextView) findViewById(R.id.total);
        percent = (TextView) findViewById(R.id.percent);

       // btntotal.setOnClickListener(this);
        //btnpercent.setOnClickListener(this);


        btntotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                total.setText(String.valueOf(total()));
                Toast.makeText(getApplicationContext(),"Total Marks is: "+sum,Toast.LENGTH_SHORT).show();

            }
        });
        btnpercent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double per, d;
                d=total();
                per=(d*100)/600;
                percent.setText(String.valueOf(per));
                Toast.makeText(getApplicationContext(),"Percentage is: "+per+"%",Toast.LENGTH_SHORT).show();
            }
        });

    }

    int total()
    {
        i1=Integer.valueOf(input1.getText().toString());
        i2=Integer.valueOf(input2.getText().toString());
        i3=Integer.valueOf(input3.getText().toString());
        i4=Integer.valueOf(input4.getText().toString());
        i5=Integer.valueOf(input5.getText().toString());
        i6=Integer.valueOf(input6.getText().toString());
        sum=i1+i2+i3+i4+i5+i6;
        return sum;

    }


    /*@Override
        public void onClick (View v){
            i1 = Integer.valueOf(input1.getText().toString());
            i2 = Integer.valueOf(input2.getText().toString());
            i3 = Integer.valueOf(input3.getText().toString());
            i4 = Integer.valueOf(input4.getText().toString());
            i5 = Integer.valueOf(input5.getText().toString());
            i6 = Integer.valueOf(input6.getText().toString());

            if (btntotal == v) {
                sum = i1 + i2 + i3 + i4 + i5 + i6;
                total.setText(String.valueOf(sum));
            }
            if (btnpercent == v) {
                d = sum / 600;
                per = d * 100;
                percent.setText(String.valueOf(per));
            }
        }*/
    }



